Sudah saya push di github.com di
https://github.com/Lyfora/bangkit_air

dan bisa diakses di
https://bangkitair-q3sriwjzjyrxqpsxp49p2e.streamlit.app/

Data Asli tidak saya sertakan dikarenakan over>25mb
